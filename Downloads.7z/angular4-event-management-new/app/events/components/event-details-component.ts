import {Component , Input, Output, EventEmitter} from '@angular/core';

import {Event} from '../models/event';

@Component({
    selector:"event-details",
    templateUrl:'app/events/views/events.details.component.html'
})
export class EventDetailsComponent{
    @Input()    event:Event;
    imageHeight:string = "100px";
    imageWidth:string = "100px";
    @Output() thankyou:EventEmitter<string> = new EventEmitter<string>();

  /*  constructor(){
        this.event=new Event(1, 'JQTRN', 'jquery seminar', 'seminar on jquery 3 new features', new Date(), new Date(),200, 80, 'app/images/JQuery.png');
    }*/
    sendThankyouNote(){
        this.thankyou.emit("Received data");
    }
}