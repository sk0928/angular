"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Post = (function () {
    function Post() {
    }
    return Post;
}());
exports.Post = Post;
//# sourceMappingURL=post.js.map