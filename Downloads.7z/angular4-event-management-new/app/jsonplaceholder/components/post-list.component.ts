

import { Component,OnInit } from "@angular/core"
import { Post} from "../models/post";
import { PostsService } from "../services/posts.service";

@Component({
    selector:'jph-posts',
    templateUrl : 'app/jsonplaceholder/views/posts-list.component.html'
})

export class PostsListComponent implements OnInit {
    constructor(private _postService :PostsService){

    }
    posts :Post[];
    ngOnInit():void{
        this._postService.getPosts().subscribe(
            data=>this.posts=data,
            err=>console.log(err),
            ()=>console.log('Service call complted')
        );
    }
}