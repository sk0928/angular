

// import { Injectable } from '@angular/core';
// import { Http } from '@angular/http';
// import { Post } from '../models/post';
// import { Observable } from "rxjs";
// import "rxjs/add/operator/map";

// @Injectable()

// export class PostService{
//     constructor(private _http : Http){

//     }
//     private url : string ="https://jsonplaceholder.typicode.com/posts";
//     getPosts(): Observable <Posts[]>{
//         return this._http.get(this.url).map(res=> res.json());
//     }
// }


import {Injectable} from "@angular/core";
import {Http} from "@angular/http";
import {Observable} from "rxjs";
import "rxjs/add/operator/map";

import {Post} from '../models/post';

@Injectable()

export class PostsService{
    constructor( private _http:Http){

    }
    private url:string = "https://jsonplaceholder.typicode.com/posts";
    getPosts():Observable<Post[]>{
        return this._http.get(this.url).map(res => res.json());
    }
}  
