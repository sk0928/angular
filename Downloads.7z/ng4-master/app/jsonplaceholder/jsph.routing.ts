import { ModuleWithProviders } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { PostListComponent} from './components/posts-list.components';

const jphRoutes : Routes=[{
    path :'',
    component : PostListComponent
}]

export const jphRouting : ModuleWithProviders=
RouterModule.forChild(jphRoutes);