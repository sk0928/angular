"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var posts_list_components_1 = require("./components/posts-list.components");
var jphRoutes = [{
        path: '',
        component: posts_list_components_1.PostListComponent
    }];
exports.jphRouting = router_1.RouterModule.forChild(jphRoutes);
//# sourceMappingURL=jsph.routing.js.map