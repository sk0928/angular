import { NgModule } from '@angular/core';
import { HttpModule } from "@angular/http";
import { CommonModule } from "@angular/common";

import { PostListComponent } from './components/posts-list.components';


import { PostsService } from './services/posts.service';
import {jphRouting} from './jsph.routing';
@NgModule({
    imports: [HttpModule, CommonModule,jphRouting],
    exports: [PostListComponent],
    declarations: [PostListComponent],
    providers: [PostsService],
})
export class JsonPlaceholderModule { }
