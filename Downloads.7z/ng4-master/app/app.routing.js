"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
// import { eventRouting } from "./events/events.routing";
// import { jphRouting } from "./jsonplaceholder/jsph.routing";
// import { homeRouting } from "./home/home.routing";
var homeRoutes = [{
        path: 'home',
        loadChildren: 'app/home/home.module#HomeModule'
    }];
var eventRoutes = [{
        path: 'events',
        loadChildren: 'app/events/events.module#EventsModule'
    }];
var jphRoutes = [{
        path: 'posts',
        loadChildren: 'app/jsonplaceholder/jsonplaceholder.module#JsonPlaceholderModule'
    }];
var appRoutes = [
    {
        path: '',
        redirectTo: '/',
        pathMatch: 'full'
    },
];
var rootRoutes = homeRoutes.concat(eventRoutes, jphRoutes, appRoutes);
exports.routing = router_1.RouterModule.forRoot(rootRoutes);
//# sourceMappingURL=app.routing.js.map