import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'cep-home',
    template: '<h1 [innerText]="title"></h1>'
})

export class HomeComponent {
    constructor() { }

    title: string = "Welcome To Capgemini Events Portal Home";
}