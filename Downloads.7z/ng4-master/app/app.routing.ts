import { ModuleWithProviders } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { HomeComponent } from "./home/components/home.component";
import { EventsListComponent } from "./events/components/events-list.component";
import { EventDetailsComponent } from "./events/components/event-details.component";
import { PostListComponent } from "./jsonplaceholder/components/posts-list.components";

// import { eventRouting } from "./events/events.routing";
// import { jphRouting } from "./jsonplaceholder/jsph.routing";
// import { homeRouting } from "./home/home.routing";

const homeRoutes :Routes=[{
    path :'home',
    loadChildren : 'app/home/home.module#HomeModule'
}]

const eventRoutes : Routes=[{
    path :'events',
    loadChildren :'app/events/events.module#EventsModule'
}]

const jphRoutes : Routes=[{
    path :'posts',
    loadChildren :'app/jsonplaceholder/jsonplaceholder.module#JsonPlaceholderModule'
}]

const appRoutes: Routes = [
    {
        path: '',
        redirectTo: '/',
        pathMatch: 'full'
    },
    // { path: '**', component: HomeComponent } //Page not found component
];

const rootRoutes : Routes =[
    ...homeRoutes,
    ...eventRoutes,
    ...jphRoutes,
    ...appRoutes
]
export const routing: ModuleWithProviders = RouterModule.forRoot(rootRoutes);