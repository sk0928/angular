import { RouterModule, Routes, } from "@angular/router";
import { EventsListComponent} from './components/events-list.component';
import { EventDetailsComponent} from './components/event-details.component';
import {ModuleWithProviders} from "@angular/core";
import { NewEventComponent } from "./components/new-event-component";
const eventRoutes : Routes=[{
    path :'',
    component: EventsListComponent
},
{
    path : 'register',
    component : NewEventComponent
},
{
    path : ':id',
    component : EventDetailsComponent
}]

export const eventRouting : ModuleWithProviders =
RouterModule.forChild(eventRoutes);