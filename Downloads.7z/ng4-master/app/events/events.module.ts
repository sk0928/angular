import { NgModule } from "@angular/core";
import { FormsModule } from '@angular/forms';
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { eventRouting } from "./events.routing";

import { EventsListComponent } from './components/events-list.component';
import { EventDetailsComponent } from './components/event-details.component';
import { NewEventComponent } from "./components/new-event-component";

/// Pipes
import { FirstLetterCapital } from './pipes/first-letter-capital-pipe';
import { FilterBy } from './pipes/filter-by-pipe';

//Services
import { EventsService } from './services/events.service';

@NgModule({
    imports: [FormsModule, CommonModule, RouterModule,eventRouting],
    declarations: [EventsListComponent, EventDetailsComponent, FirstLetterCapital, FilterBy,NewEventComponent],
    providers: [EventsService],
    exports: [EventsListComponent, EventDetailsComponent,NewEventComponent]
})
export class EventsModule {

}