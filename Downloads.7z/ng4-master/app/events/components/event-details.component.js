"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var events_service_1 = require("../services/events.service");
var EventDetailsComponent = (function () {
    function EventDetailsComponent(_eventsService, route) {
        this._eventsService = _eventsService;
        this.route = route;
        this.imageHeight = "100px";
        this.imageWidth = "100px";
        this.thankyou = new core_1.EventEmitter();
    }
    EventDetailsComponent.prototype.showEventDetails = function () {
        var _this = this;
        this.route.params.subscribe(function (params) {
            _this.id = params['id'];
            console.log(_this.id);
        });
        this.event = this._eventsService.getSingleEvent(this.id);
    };
    EventDetailsComponent.prototype.ngOnInit = function () {
        this.showEventDetails();
    };
    /*  constructor(){
          this.event=new Event(1, 'JQTRN', 'jquery seminar', 'seminar on jquery 3 new features', new Date(), new Date(),200, 80, 'app/images/JQuery.png');
      }*/
    EventDetailsComponent.prototype.sendThankyouNote = function () {
        this.thankyou.emit("Received data");
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", core_1.EventEmitter)
    ], EventDetailsComponent.prototype, "thankyou", void 0);
    EventDetailsComponent = __decorate([
        core_1.Component({
            selector: "event-details",
            templateUrl: 'app/events/views/events-details.component.html'
        }),
        __metadata("design:paramtypes", [events_service_1.EventsService, router_1.ActivatedRoute])
    ], EventDetailsComponent);
    return EventDetailsComponent;
}());
exports.EventDetailsComponent = EventDetailsComponent;
//# sourceMappingURL=event-details.component.js.map