import { Component ,OnInit} from "@angular/core";
import {Event} from '../models/event';
import { EventsService } from "../services/events.service";
@Component({
    selector : 'new-event',
    templateUrl : 'app/events/views/new-event.component.html'
})

export class NewEventComponent implements OnInit{
    title : string = "Register new Event";
    newEvent : Event;
    constructor(private eventService : EventsService){

    }
    ngOnInit(){

        this.newEvent = new Event();
    }
    registerNewEvent(){
        this.eventService.insertEvent(this.newEvent);
    }
}