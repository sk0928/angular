import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from "@angular/router";
import { Event } from '../models/event';
import { EventsService } from "../services/events.service";

@Component({
    selector: "event-details",
    templateUrl: 'app/events/views/events-details.component.html'
})
export class EventDetailsComponent implements OnInit {
    event: Event;
    imageHeight: string = "100px";
    imageWidth: string = "100px";
    @Output() thankyou: EventEmitter<string> = new EventEmitter<string>();
    id:number;
    constructor(private _eventsService: EventsService, private route: ActivatedRoute) {

    }
    showEventDetails() {
         this.route.params.subscribe(params => {
            this.id = params['id'];
            console.log(this.id);
        });
        this.event = this._eventsService.getSingleEvent(this.id);
    }
    ngOnInit() {
        this.showEventDetails();
    }
    /*  constructor(){
          this.event=new Event(1, 'JQTRN', 'jquery seminar', 'seminar on jquery 3 new features', new Date(), new Date(),200, 80, 'app/images/JQuery.png');
      }*/
    sendThankyouNote() {
        this.thankyou.emit("Received data");
    }
}