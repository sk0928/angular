import { Component } from "@angular/core";

import { Event } from "../models/event";

@Component({
    selector: 'events-list',
    templateUrl: 'app/events/views/events-list.component.html'
})
export class EventsListComponent {
    title: string = "CapGemini Future Events List";
    subTitle: string = "Managed by HR Team of Pune";
    searchBy: string = "";
    selectedEvent: Event;
    showEventDetails(event: Event): void {
        this.selectedEvent = event;
    }
    events: Event[] = [
        {
            eventId: 1,
            eventCode: 'CEPJQ3',
            eventName: 'jQuery 3 Seminar',
            description: 'jQuery 3 Seminar on new features',
            startDate: new Date(),
            endDate: new Date(),
            fees: 200,
            totalRegistration: 78,
            logo: 'images/jquery.png'
        },
        {
            eventId: 2,
            eventCode: 'CEPMS6',
            eventName: 'Microsoft MVC 6',
            description: 'Microsoft MVC 6 Seminar on new features',
            startDate: new Date(),
            endDate: new Date(),
            fees: 500,
            totalRegistration: 58,
            logo: 'images/mvc.png'
        },
        {
            eventId: 3,
            eventCode: 'CEPNG4',
            eventName: 'Angular 4 Seminar',
            description: 'Angular 4 Seminar on new features',
            startDate: new Date(),
            endDate: new Date(),
            fees: 800,
            totalRegistration: 98,
            logo: 'images/angular.png'
        },
        {
            eventId: 4,
            eventCode: 'CEPNG2',
            eventName: 'Angular 2 Seminar',
            description: 'Angular 2 Seminar on new features',
            startDate: new Date(),
            endDate: new Date(),
            fees: 300,
            totalRegistration: 68,
            logo: 'images/angular.png'
        },
        {
            eventId: 5,
            eventCode: 'CEPNG1',
            eventName: 'Angular JS 1.x Seminar',
            description: 'Angular JS 1.x Seminar on new features',
            startDate: new Date(),
            endDate: new Date(),
            fees: 400,
            totalRegistration: 88,
            logo: 'images/angular.png'
        }
    ];
    //event: Event;
    constructor() {
        //this.event = new Event(1, 'CEPJQ3', 'jQuery 3 Seminar', 'Seminar on jQuery 3 New Features', new Date(), new Date(), 200, 45, 'images/jquery.png');
    }
}